import Image from "next/image";
import { CarouselProvider, Slider, Slide, ButtonBack, ButtonNext } from "pure-react-carousel";
import "pure-react-carousel/dist/react-carousel.es.css";
const WorkSlider = () => {
    
    return (

     <h1>fds</h1>
    )
}

export default WorkSlider;